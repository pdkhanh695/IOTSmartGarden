/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DELAY_CONFIG_H
#define __DELAY_CONFIG_H

#include "include.h"
void UART1_Configuration (void);
void UU_PutChar(USART_TypeDef* USARTx, uint8_t ch);
void UU_PutString(USART_TypeDef* USARTx, uint8_t * str);
void UU_PutNumber(USART_TypeDef* USARTx, uint32_t x);

void UART2_Configuration (void);
void UARTPuts(USART_TypeDef *USARTx, const char *s);
void UARTPutn(USART_TypeDef *USARTx, long Num);

#endif /* __DELAY_CONFIG_H */

