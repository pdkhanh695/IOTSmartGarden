/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef SYSTEMHANDLER_H_
#define SYSTEMHANDLER_H_
#include "include.h"

 bool encoder(char* str);
 void read_data_sensor();
 void decoder(int light, int hum, int temp);
 void init_TSL2561(void);
#endif /* SYSTEMHANDLER_H_ */