Config pin uart:  
	UART1 PIN OUT:  /*Recieve and transmit with ESP8266 */
		PA9 : TX 
		PA10 : RX
	UART2 PIN OUT: /*Communication debug */
		PA2 : TX 
		PA3 : RX
Config pin i2c: 
	I2C2 PIN OUT: /*Read data from TSL2561 */
		PB10 : SDA
		PB11 : SCL
Config pin ADC: 
	ADC PIN OUT: /*Read light sensor*/
		PC4 : Read data

