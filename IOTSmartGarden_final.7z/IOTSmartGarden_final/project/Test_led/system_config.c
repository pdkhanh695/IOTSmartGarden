#include "include.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static SYSTEM_STATE e_SystemState = SYSTEM_INITIALIZE;
/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/

SYSTEM_STATE system_GetState(void)
{
	return e_SystemState;
}

void system_SetState(SYSTEM_STATE SysState)
{
	e_SystemState = SysState;
}
void system_Process_System_State(void)
{
	switch (system_GetState())
	{
		case SYSTEM_INITIALIZE:
			//UU_PutString(USART2,(uint8_t *)"1");
			break;
		case SYSTEM_WAIT_TO_RUN:
			//UU_PutString(USART2,(uint8_t *)"2");
			break;
		case SYSTEM_START_WATER:
			//UU_PutString(USART2,(uint8_t *)"3");
			break;
		case SYSTEM_START_SPRAY:
			//UU_PutString(USART2,(uint8_t *)"4");
			break;
		case SYSTEM_STOP_WATER:
			//UU_PutString(USART2,(uint8_t *)"5");
			//ProcessSpeedControl();
			break;
		case SYSTEM_STOP_SPRAY:
			//UU_PutString(USART2,(uint8_t *)"6");
			break;
		case SYSTEM_RESET_WATER:
			//UU_PutString(USART2,(uint8_t *)"7");
			//speed_Enable_Hbridge(false);
			//ProcessSpeedControl();
			break;
		case SYSTEM_RESET_SPRAY:
			//UU_PutString(USART2,(uint8_t *)"8");
			//pid_Wallfollow_process();
			//ProcessSpeedControl();
			break;
		case SYSTEM_RUNING_UP:
			//UU_PutString(USART2,(uint8_t *)"9");
			//ProcessSpeedControl();
			break;
		case SYSTEM_RUNING_DOWN:
			//UU_PutString(USART2,(uint8_t *)"10");
			//speed_Enable_Hbridge(false);
			//ProcessSpeedControl();
			break;
		case SYSTEM_RUNING_FORWARD:
			//UU_PutString(USART2,(uint8_t *)"11");
			break;
		case SYSTEM_RUNING_BACKWARD:
			//UU_PutString(USART2,(uint8_t *)"12");
			break;
		case SYSTEM_RUNING_LEFT:
			//UU_PutString(USART2,(uint8_t *)"13");
			break;
		case SYSTEM_RUNING_RIGHT:
			//UU_PutString(USART2,(uint8_t *)"14");
			break;
	}
}
