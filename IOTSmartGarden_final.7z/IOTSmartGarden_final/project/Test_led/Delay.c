#include "include.h"

void Delay_ms(uint16_t time){
uint32_t time_n=time*12000;
	while(time_n!=0){time_n--;}
}
void Delay_us(uint16_t time){
uint32_t time_n=time*12;
	while(time_n!=0){time_n--;}
}
