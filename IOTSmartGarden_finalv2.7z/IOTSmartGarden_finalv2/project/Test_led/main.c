#include "include.h"
#include "MyMotor.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


//Pin out UART:
//		UART-TX PA3 
//		UART-RX PA2
//	I2C: 

int PDM_ctr_System_State = 0;

#define I2C_Chanel I2C2
#define Device_Add 0xFF
#define I2C_Dir 0x01

void GPIO_Configuration(void);
void Delay_ms(uint16_t time);
void decoder(int, int , int);
bool encoder(char* str);

int x1=0, y1=0, z1=0;

int main(void)
{
	GPIO_Configuration();
	UART2_Configuration();
	UART1_Configuration();
	init_ADC();
	MyI2C_Init(I2C2, 100000, TSL2561_ADDR);
  unsigned char time = 2;
	UU_PutString(USART1,(uint8_t *)"Start UART1");
	UU_PutString(USART2,(uint8_t *)"Start UART2");
	init_TSL2561();
  TIM4_Configuration();
	TSL2561_setPowerUp();
	system_SetState(SYSTEM_INITIALIZE);
	/*Config input pin */
	
	while(1){
		system_Process_System_State();
}
}


























/*
	while(1){
		//system_Process_System_State();
		//SUU_PutString(USART1,(uint8_t *)"UART3----->");
		//Delay_ms(1000);
		//UU_PutString(USART2,(uint8_t *)"UART2----->");
		//UU_PutString(USART2,(uint8_t *)"Got factory ID: ");
		//UARTPuts(USART2, (char*)"xxxxxx");
		//json_object_set_new(root, "data", json_arr);
	
		//json_array_append( json_arr, json_integer(11));
		//json_array_append( json_arr, json_integer(12));
		//Delay_ms(1000);
		//UU_PutString(USART1, (uint8_t *)a);
		//encoder(a);
		/*
		decoder(x1, y1, z1);
		x1 = x1 + 19;
		y1 = y1 + 10;
		z1 = z1 + 20;
		if(x1 >400){
			x1 = 10;
		}
		if(y1 >400){
			y1 = 10;
		}
		if(z1 >400){
			z1 = 10;
		}
		*/
		/*
	}
}
	
  //->CTSL2561_setTiming_ms(gain, time, &ms);
	//print("\r\nUSART2 is OK\r\n");
	//->
	/*
  unsigned char ID;

  if (TSL2561_getID(&ID))
  {
   char string[2];
		UU_PutString(USART2,(uint8_t *)"Got factory ID:  ");
		UARTPutn(USART2, ID);
		UU_PutString(USART2,(uint8_t *)"\n");
  // sprintf(string, "%x", ID);

    //  print("Got factory ID: 0X");
    //  print(", should be 0X5X\r\n");
  }
  else
  {
		UU_PutString(USART2,(uint8_t *)"Error");
		UU_PutString(USART2,(uint8_t *)"\n");
    // print("error get ID\r\n");
  }

    // Initialize I2C 
    while (1)
    {
		UU_PutString(USART2,(uint8_t *)"Read reg = ");
		UARTPutn(USART2, *(uint16_t *) 0x000001);
			*(uint16_t *) 0x000001 = 100l;
		UARTPutn(USART2, *(uint16_t *) 0x000001);
		Delay_ms(500);
		*/
			/*
   unsigned int data0, data1;

   if (TSL2561_getData(&data0, &data1))
   {
    double lux;    // Resulting lux value
    bool good;  // True if neither sensor is saturated
		UU_PutString(USART2,(uint8_t *)"\n");
    // Perform lux calculation:
    good = TSL2561_getLux(gain, ms, data0, data1, &lux);
		//UU_PutString(USART2,(uint8_t *)"Data 0= ");
		//UARTPutn(USART2, data0);
		//Delay_ms(200);
		//UU_PutString(USART2,(uint8_t *)"\n");
		//UU_PutString(USART2,(uint8_t *)"Data 1= ");
		//UARTPutn(USART2, data1);
		//Delay_ms(200);
		//UU_PutString(USART2,(uint8_t *)"\n");
		UU_PutString(USART2,(uint8_t *)"Lux = ");
		UARTPutn(USART2, lux);
		Delay_ms(500);
		UU_PutString(USART2,(uint8_t *)"\n");
		//TSL2561_setPowerUp();
    }
		*/

/*
int main(void)
{
	GPIO_Configuration();
	UART2_Configuration();
	init_ADC();
	
	GPIO_WriteBit(GPIOD,GPIO_Pin_2,(BitAction)(0));
	GPIO_WriteBit(GPIOC,GPIO_Pin_6,(BitAction)(0));
	GPIO_WriteBit(GPIOC,GPIO_Pin_7,(BitAction)(0));
	//uint16_t a;
	
  while (1)
  {
		
		
		//a = ADC_GetConversionValue(ADC1);
		//UARTPutn(USART2, a);
	 // Delay_ms(1000);
	
		uint8_t * a; 
		a = "det cm may " ;
		UU_PutString(USART2, a);
		Delay_ms(500);
		UARTPutn(USART2, -100);
		Delay_ms(500);
		*/
		//UU_PutNumber(USART2, -100);
		//UARTPutn(USART2, 1000);
		//Delay_ms(1000);		
		/*
		GPIO_WriteBit(GPIOD,GPIO_Pin_2,(BitAction)(1));
		StepMotorx_control(10, Motor1, 1, CCW);
		Delay_ms(500);
		StepMotorx_control(10, Motor1, 1, CW);
		GPIO_WriteBit(GPIOD,GPIO_Pin_2,(BitAction)(0));
		Delay_ms(500);
		*/
//  }
//}


	