#include "include.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
uint8_t step_x = 30; 
uint8_t step_y = 12; 
uint8_t step_z = 5; 
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static SYSTEM_STATE e_SystemState = SYSTEM_INITIALIZE;

/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/
void go_home(void);
void water_control(void);
void sowing_control(void);
void water_control_on(void);
void water_control_off(void);
void sowing_control_on(void);
void sowing_control_off(void);
void setup_gaphat(uint8_t mode);
void gieohat(int x, int y);
	
SYSTEM_STATE system_GetState(void)
{
	return e_SystemState;
}

void system_SetState(SYSTEM_STATE SysState)
{
	e_SystemState = SysState;
}
void system_Process_System_State(void)
{
	switch (system_GetState())
	{
		case SYSTEM_INITIALIZE:
			//UU_PutString(USART2,(uint8_t *)"1");
		
			break;
		case SYSTEM_WAIT_TO_RUN: // go to home
			//UU_PutString(USART2,(uint8_t *)"2");
			go_home();
			system_SetState(SYSTEM_INITIALIZE);		
			break;
		case SYSTEM_START_WATER:
			UU_PutString(USART2,(uint8_t *)"3");
			water_control();
		  go_home();
		  system_SetState(SYSTEM_INITIALIZE);
			break;
		case SYSTEM_START_SPRAY:
			UU_PutString(USART2,(uint8_t *)"4");
			sowing_control();
		  go_home();
		  system_SetState(SYSTEM_INITIALIZE);
			break;
		case SYSTEM_STOP_WATER:
			//UU_PutString(USART2,(uint8_t *)"5");
			//ProcessSpeedControl();
			break;
		case SYSTEM_STOP_SPRAY:
			//UU_PutString(USART2,(uint8_t *)"6");
			break;
		case SYSTEM_RESET_WATER:
			//UU_PutString(USART2,(uint8_t *)"7");
			go_home();
			system_SetState(SYSTEM_INITIALIZE);		
			break;
		case SYSTEM_RESET_SPRAY:
			//UU_PutString(USART2,(uint8_t *)"8");
			go_home();
			system_SetState(SYSTEM_INITIALIZE);		
			break;
		case SYSTEM_RUNING_UP:
		  //UU_PutString(USART2,(uint8_t *)"9");
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5)){
				StepMotorx_control(10, Motor3, 1, CW);
				Delay_ms(1);
			}
			system_SetState(SYSTEM_INITIALIZE);
			break;
		case SYSTEM_RUNING_DOWN:
		//UU_PutString(USART2,(uint8_t *)"10");
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5)){
				StepMotorx_control(10, Motor3, 1, CCW);
				Delay_ms(1);
			}
			system_SetState(SYSTEM_INITIALIZE);
			break;
		case SYSTEM_RUNING_FORWARD: // X
			//UU_PutString(USART2,(uint8_t *)"11");
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1)){
				StepMotorx_control(10, Motor1, 1, CW);
				Delay_ms(1);
			}
			system_SetState(SYSTEM_INITIALIZE);
			break;
		case SYSTEM_RUNING_BACKWARD:
			//UU_PutString(USART2,(uint8_t *)"12");
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1)){
				StepMotorx_control(10, Motor1, 1, CCW);
			//UU_PutString(USART2,(uint8_t *)"stuck");
			}
			system_SetState(SYSTEM_INITIALIZE);
			break;
		case SYSTEM_RUNING_LEFT: //y 
			//UU_PutString(USART2,(uint8_t *)"13");
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4)){
				StepMotorx_control(10, Motor2, 1, CW);
			//UU_PutString(USART2,(uint8_t *)"stuck");
			}
			system_SetState(SYSTEM_INITIALIZE);
			break;
		case SYSTEM_RUNING_RIGHT:
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4)){
				StepMotorx_control(10, Motor2, 1, CCW);
			//UU_PutString(USART2,(uint8_t *)"stuck");
			}
			system_SetState(SYSTEM_INITIALIZE);
			//UU_PutString(USART2,(uint8_t *)"14");
			break;
	}
}
void go_home(void){
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5)){
				StepMotorx_control(10, Motor3, 1, CW);
			}
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4)){
				StepMotorx_control(10, Motor2, 1, CW);
			}
			while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1)){
				StepMotorx_control(10, Motor1, 1, CCW);
			}
}

//sowing_control_on();
//sowing_control_off();
void water_control(){
	StepMotorx_control(50, Motor3, 1, CCW); // Down step 50
	for(int x = 0; x < step_x ; x++ ){ // turn x 
		//Todo: x function
		StepMotorx_control(100, Motor1, 1, CW);
		for(int y = 0; y < step_y; y++){ // di het hang 
			//Todo : y function
			if(x % 2 == 0){
			StepMotorx_control(100, Motor2, 1, CCW);  // Cho di nguoc lai 
			}
			else{
				StepMotorx_control(100, Motor2, 1, CW);
			}
			StepMotorx_control(50, Motor3, 1, CCW); // Down step 50
			//Function gieo hat
			water_control_on();
			Delay_ms(1000); //1s
			water_control_off();
			StepMotorx_control(50, Motor3, 1, CW); // Up step 50
			while(system_GetState() == SYSTEM_STOP_WATER){
				;//Todo something
			}
			if(system_GetState() == SYSTEM_RESET_WATER) break;
		}
		if(system_GetState() == SYSTEM_RESET_WATER) break;
	}
}
void sowing_control(void){
	for(int x = 0; x < step_x ; x++ ){ // turn x 
		for(int y = 0; y < step_y; y++){
			UU_PutString(USART2,(uint8_t *)"Goome_modesowing");
			go_home();
			UU_PutString(USART2,(uint8_t *)"Gaphat");
			setup_gaphat(1);
			UU_PutString(USART2,(uint8_t *)"gieohat");
			gieohat(x, y);
			while(system_GetState() == SYSTEM_STOP_WATER){
				;//Todo something
			}
			if(system_GetState() == SYSTEM_RESET_WATER) break;
		}
		if(system_GetState() == SYSTEM_RESET_WATER) break;
	}
}
void water_control_on(void){
	UU_PutString(USART2,(uint8_t *)"Tuoi");
	GPIO_WriteBit(GPIOB, GPIO_Pin_9, 1);
}
void water_control_off(void){
	UU_PutString(USART2,(uint8_t *)"kotuoi");
	GPIO_WriteBit(GPIOB, GPIO_Pin_9, 0);
}
void sowing_control_on(void){
	UU_PutString(USART2,(uint8_t *)"gieo");
	GPIO_WriteBit(GPIOD, GPIO_Pin_2, 1);
}
void sowing_control_off(void){
	UU_PutString(USART2,(uint8_t *)"kogieo");
	GPIO_WriteBit(GPIOD, GPIO_Pin_2, 0);
}
void setup_gaphat(uint8_t mode){
	if(mode == 1){
	  StepMotorx_control(100, Motor1, 1, CW); //x
	  StepMotorx_control(100, Motor1, 1, CW); //y
		StepMotorx_control(50, Motor3, 1, CCW); // Down step 50
		sowing_control_on();
		Delay_ms(500);
		StepMotorx_control(50, Motor3, 1, CW); // Up step 50
	}
}
void gieohat(int x, int y){
	StepMotorx_control(100*x, Motor1, 1, CW); //x
	StepMotorx_control(10*y, Motor2, 1, CCW);
	sowing_control_on();
	Delay_ms(500);
	StepMotorx_control(50, Motor3, 1, CW); // Up step 50
}