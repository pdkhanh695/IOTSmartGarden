/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MYMOTOR_TIMER_H
#define __MYMOTOR_TIMER_H
#include "include.h"

void TIM4_Configuration(void);

#endif /* __MYMOTOR_TIMER_H */

