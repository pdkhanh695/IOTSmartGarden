#include "include.h"
#include "define.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
 //bool gain = 0;        // Gain setting, 0 = X1, 1 = X16;
 //unsigned int ms;  // Integration ("shutter") time in milliseconds

 bool encoder(char* str);
 void read_data_sensor();
 void decoder(int light, int hum, int temp);
 
bool gain;        // Gain setting, 0 = X1, 1 = X16;
unsigned int ms;  // Integration ("shutter") time in milliseconds
unsigned char time = 2;
uint16_t temp = 0;
uint16_t hum = 0;

void init_TSL2561(){
	gain = 0;
	TSL2561_setTiming_ms(gain, time, &ms);
}
void read_data_sensor(){
	double lux;
	unsigned int data0, data1;
	if(TSL2561_getData(&data0, &data1))
		{    
			
			bool good;  // True if neither sensor is saturated
			// Perform lux calculation:
			good = TSL2561_getLux(gain, ms, data0, data1, &lux);
			TSL2561_setPowerUp();
		}
	/*temp = temp + 10;
		if(temp  > 80) { 
			temp = 20;
		}*/
	//temp = 	ADC_GetConversionValue(ADC1);
  //ADC_GetConversionValue(ADC1);
	/*UU_PutString(USART2,(uint8_t *)"1 ---->");
	UARTPutn(USART2, ADCConvertedValue[0]);
  UU_PutString(USART2,(uint8_t *)"\n");
	UU_PutString(USART2,(uint8_t *)"2 ---->");
	UARTPutn(USART2, ADCConvertedValue[1]);
	UU_PutString(USART2,(uint8_t *)"\n");*/
	temp = ADCConvertedValue[1];
	hum = ADCConvertedValue[0];
	//UARTPutn(USART2, lux);
	//UARTPutn(USART2, ADC_GetConversionValue(ADC1));
	//UU_PutString(USART2,(uint8_t *)"run decoder ");
	decoder(lux, hum , temp);
}

bool encoder(char* str){
	UU_PutString(USART2,(uint8_t *)"run decoder ");
	json_error_t error;
	const char *message_text;
	int a;
	json_t *root = json_loads(str, 0, &error);
	json_t *commits = json_object_get(root, "age");
	json_t *commits2 = json_object_get(root, "city");
	message_text = json_string_value(commits);
	a = json_integer_value(commits2);
	UU_PutString(USART2,(uint8_t *)"String = ");
	UU_PutString(USART2,(uint8_t *)message_text);
	UU_PutString(USART2,(uint8_t *)"a = ");
	UU_PutNumber(USART2,a);
	json_decref(commits);
	json_decref(commits2);
	json_decref(root);
	return 1;
}
void decoder(int light, int hum, int temp){
		 /*Json example */
		char* s ;
		json_t *root = json_object();
	  //DynamicJsonBuffer jsonBuffer(bufferSize);
		//json_t *json_arr = json_array();
	
		json_object_set_new(root, "Light", json_integer(light));
    json_object_set_new(root, "Hum", json_integer(hum));
	  json_object_set_new(root, "Tem", json_integer(temp));

		s = json_dumps(root, 0);
		UU_PutString(USART1,(uint8_t *)s);
		free(s);
		json_decref(root);
	
	}	
	