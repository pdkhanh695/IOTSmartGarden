/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __INCLUDE_CONFIG_H
#define __INCLUDE_CONFIG_H
#include "stm32f10x.h"
#include "Define.h"
#include "MyUart.h"
#include "MyMotor.h"
#include "Delay.h"
#include "MyADC.h"
#include "MyI2C.h"
#include "TSL2561.h"
#include "stdbool.h" 
#include "math.h"
#include "system_config.h"
#include "Timer_config.h"
#include "system_handler.h"
#include "jansson.h"                    // Keil::Data Exchange:JSON:Jansson
#include <jansson_config.h>

extern __IO uint16_t ADCConvertedValue[2];// = {0,0};

#define I2Cx_RCC        RCC_APB1Periph_I2C2
#define I2Cx            I2C2
#define I2C_GPIO_RCC    RCC_APB2Periph_GPIOB
#define I2C_GPIO        GPIOB
#define I2C_PIN_SDA     GPIO_Pin_11
#define I2C_PIN_SCL     GPIO_Pin_10
 

/*Khoi tao bien cau hinh*/

#endif /* __INCLUDE_CONFIG_H */

