/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MYMOTOR_CONFIG_H
#define __MYMOTOR_CONFIG_H
#include "include.h"

#define Motor_num int8_t
#define Ratio_step int8_t
#define PulsePermm 1 //mm
#define CW 0
#define CCW 1

typedef enum{
	Motor1,
	Motor2,
	Motor3
}Motornum;

int8_t StepMotorx_control(int8_t distance, Motor_num motor, Ratio_step ratio, uint8_t Dir );

#endif /* __MYMOTOR_CONFIG_H */

