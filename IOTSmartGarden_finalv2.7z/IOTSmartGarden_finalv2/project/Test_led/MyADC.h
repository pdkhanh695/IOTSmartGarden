/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MYMOTOR_ADC_H
#define __MYMOTOR_ADC_H
#include "include.h"

void init_ADC(void);

#endif /* __MYMOTOR_ADC_H */

