/* Define to prevent recursive inclusion -------------------------------------*/
/*http://www.handsonembedded.com/stm32f103-spl-tutorial-6/ */
#ifndef GPIO_H
#define GPIO_H

void GPIO_Configuration(void);

#endif /* GPIO_H_ */
