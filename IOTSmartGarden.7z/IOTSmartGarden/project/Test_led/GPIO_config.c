#include "include.h"

void GPIO_Configuration(void)
{
	GPIO_InitTypeDef	GPIO_InitStructure_;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	/*
	GPIO_InitStructure_.GPIO_Pin = GPIO_Pin_9 ;
	GPIO_InitStructure_.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure_.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure_);
	
	GPIO_InitStructure_.GPIO_Pin = GPIO_Pin_2 ;
	GPIO_InitStructure_.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure_.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure_);
	*/
	//Step motor 1, 2: PC6: CW PC7: CLK && PC8: CW PC9: CLK
	//Step motor 3: PC10: CW PC11: CLK
	GPIO_InitStructure_.GPIO_Pin = GPIO_Pin_6 |GPIO_Pin_7 |GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 ;
	GPIO_InitStructure_.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure_.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure_);	
	
	// Limited switch
	GPIO_InitStructure_.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_4 |GPIO_Pin_5;
	GPIO_InitStructure_.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure_.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure_);	
}

