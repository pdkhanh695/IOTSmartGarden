/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef SYSTEMCONFIG_H_
#define SYSTEMCONFIG_H_

typedef enum
{
	SYSTEM_INITIALIZE = 0,
	SYSTEM_WAIT_TO_RUN,
	SYSTEM_START_WATER,
	SYSTEM_START_SPRAY,
	SYSTEM_STOP_WATER,
	SYSTEM_STOP_SPRAY,
	SYSTEM_RESET_WATER,
	SYSTEM_RESET_SPRAY,
	SYSTEM_RUNING_UP,
	SYSTEM_RUNING_DOWN,
	SYSTEM_RUNING_FORWARD,
	SYSTEM_RUNING_BACKWARD,
	SYSTEM_RUNING_LEFT,
	SYSTEM_RUNING_RIGHT
} SYSTEM_STATE;

extern SYSTEM_STATE system_GetState(void);
extern void system_SetState(SYSTEM_STATE SysState);
extern void system_Process_System_State(void);

#endif /* SYSTEMCONFIG_H_ */