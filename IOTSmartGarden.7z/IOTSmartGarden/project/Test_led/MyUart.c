#include "include.h"
#include "string.h"
#include <stdlib.h>

#define Baurate 115200;
#define USE_USART1_INTERRUPT
#define USE_USART2_INTERRUPT

GPIO_InitTypeDef			GPIO_InitStructure__;
USART_InitTypeDef			UART_InitStructure__;
NVIC_InitTypeDef			NVIC_InitStructure__;

void UU_PutChar(USART_TypeDef* USARTx, uint8_t ch)
{
  while(!(USARTx->SR & USART_SR_TXE));
  USARTx->DR = ch;  
}
void UU_PutString(USART_TypeDef* USARTx, uint8_t * str)
{
  while(*str != 0)
  {
    UU_PutChar(USARTx, *str);
    str++;
  }
}

void UU_PutNumber(USART_TypeDef* USARTx, uint32_t x)
{
  char value[10]; //a temp array to hold results of conversion
  int i = 0; //loop index
  
  do
  {
    value[i++] = (char)(x % 10) + '0'; //convert integer to character
    x /= 10;
  } while(x);
  
  while(i) //send data
  {
    UU_PutChar(USARTx, value[--i]); 
  }
}
void UART2_Configuration (void)
	{
		  /*Cap clock cho USART v� port su dung*/
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
		
			/* Cau Tx mode AF_PP, Rx mode FLOATING  */
			GPIO_InitStructure__.GPIO_Pin = GPIO_Pin_2;
			GPIO_InitStructure__.GPIO_Mode = GPIO_Mode_AF_PP;
			GPIO_InitStructure__.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_Init(GPIOA, &GPIO_InitStructure__);
		
			GPIO_InitStructure__.GPIO_Pin = GPIO_Pin_3;
			GPIO_InitStructure__.GPIO_Mode = GPIO_Mode_IN_FLOATING;
			GPIO_Init(GPIOA, &GPIO_InitStructure__);	
		
		/*Cau hinh USART*/
			UART_InitStructure__.USART_BaudRate = Baurate;
			UART_InitStructure__.USART_WordLength = USART_WordLength_8b;
			UART_InitStructure__.USART_StopBits = USART_StopBits_1;
			UART_InitStructure__.USART_Parity = USART_Parity_No;
			UART_InitStructure__.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
			UART_InitStructure__.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
			USART_Init(USART2, &UART_InitStructure__);
				
		  /* Cau hinh vector ngat va muc uu tien */
			NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4); //USE group 4
			NVIC_InitStructure__.NVIC_IRQChannel = USART2_IRQn;
			NVIC_InitStructure__.NVIC_IRQChannelSubPriority = 0;
			NVIC_InitStructure__.NVIC_IRQChannelPreemptionPriority = 0;	
			NVIC_InitStructure__.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&NVIC_InitStructure__);
			
			/* xoa co ngat nhan cho lan dau su dung*/
			USART_ClearFlag(USART2, USART_IT_RXNE);
			
			/* Cau hinh cho phep ngat nhan*/
			USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

			/* Cho phep UART hoat dong */
			USART_Cmd(USART2, ENABLE);
	}
	
void UART1_Configuration(void)
{
    /* USART configuration structure for USART1 */
    USART_InitTypeDef usart1_init_struct;
    /* Bit configuration structure for GPIOA PIN9 and PIN10 */
    GPIO_InitTypeDef gpioa_init_struct;
     
    /* Enalbe clock for USART1, AFIO and GPIOA */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_AFIO | 
                           RCC_APB2Periph_GPIOA, ENABLE);
    #ifdef USE_USART1_INTERRUPT
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4); //USE group 4
		NVIC_InitTypeDef NVIC_InitStructure;
		NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn; 
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init( &NVIC_InitStructure );
		#endif 
    /* GPIOA PIN9 alternative function Tx */
    gpioa_init_struct.GPIO_Pin = GPIO_Pin_9;
    gpioa_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpioa_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &gpioa_init_struct);
    /* GPIOA PIN9 alternative function Rx */
    gpioa_init_struct.GPIO_Pin = GPIO_Pin_10;
    gpioa_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpioa_init_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpioa_init_struct);
 
    /* Enable USART1 */
    USART_Cmd(USART1, ENABLE);  
    /* Baud rate 9600, 8-bit data, One stop bit
     * No parity, Do both Rx and Tx, No HW flow control
     */
    usart1_init_struct.USART_BaudRate = Baurate;   
    usart1_init_struct.USART_WordLength = USART_WordLength_8b;  
    usart1_init_struct.USART_StopBits = USART_StopBits_1;   
    usart1_init_struct.USART_Parity = USART_Parity_No ;
    usart1_init_struct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    usart1_init_struct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    /* Configure USART1 */
    USART_Init(USART1, &usart1_init_struct);
    /* Enable RXNE interrupt */
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    /* Enable USART1 global interrupt */
    NVIC_EnableIRQ(USART1_IRQn);
}
void UARTPuts(USART_TypeDef *USARTx, const char *s)
{
	while(*s)
	{
		USART_SendData(USARTx,*s++);
		//UARTCharPut(UART_Base, *s++);
	}
}
void UARTPutn(USART_TypeDef *USARTx, long Num)
{
	unsigned long temp = 1;
	long NumTemp;
	NumTemp = Num;
	if (Num == 0)
	{
		UU_PutChar(USARTx, 48);
	}
	else
	{
		if (Num < 0)
		{
			UU_PutChar(USARTx, '-');
			//USART_SendData(USARTx, '-');
			Num *= -1;
		}
		while (NumTemp)
		{
			NumTemp /= 10;
			temp *= 10;
		}
		temp /= 10;
		while (temp)
		{
			UU_PutChar(USARTx,(Num / temp) % 10 + 48);
			//USART_SendData(USARTx,(Num / temp) % 10 + 48);
			temp /= 10;
		}
	}
}


/*
char *strstr(const char *str1, const char *str2)
{
  size_t len_str2 = strlen(str2);
  char *cur;

  for (cur = (char*)str1; cur != NULL; cur = strchr(cur, *str2)) {
    if (!strncmp(cur, str2, len_str2)) {
      break;
    }
    cur++;
  }

  return cur;
}
*/
/*Interrupt handler */
/*
char usart1_buff[30];
unsigned char count = 0;
void USART1_IRQHandler(void)
{
 if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) != RESET)
 {
  if(count<29)
  {
		usart1_buff[count] = USART_ReceiveData(USART1);
		if(strstr(usart1_buff,"LED1ON") != NULL)
    {
			UU_PutString(USART2,(uint8_t *)"Okie----->");
     //LED_ON(1);
     //USART1PutString("LED1 is ON\r\n");
    }count++;
  }else count = 0; //RESET counter
 }
}
*/
