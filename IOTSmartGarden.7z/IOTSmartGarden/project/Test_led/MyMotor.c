#include "include.h"

//Don vi: mm
int8_t StepMotorx_control(int8_t distance, Motor_num motor, Ratio_step ratio, uint8_t Dir ){
	/* Ratio : 1:1 1:4 1:8 1: 16
	Ex: 200 Pulse = 10 mm(distance)
			To start from position A(0mm) to B(30mm) we need 600 Pulse 
			If driver have 1/4, to move from A to B we need 600x4 pulse 
			=> Pulse = distance*200*ratio/PulsePermm
			Pulse = distance */
	/*Step motor 1, 2: PC6: CW | PC7: CLK && PC8: CW PC9: CLK*/
	//Step motor 3: PC10: CW PC11: CLK
	uint32_t Pulse;
	Pulse = distance*200*ratio/PulsePermm;
	switch (motor){
		case Motor1:
			if(Dir == CCW){
				GPIO_WriteBit(GPIOC,GPIO_Pin_6,(BitAction)(1));
			}else if (Dir == CW){
				GPIO_WriteBit(GPIOC,GPIO_Pin_6,(BitAction)(0));
			}
			for(uint32_t i = 0; i < Pulse; i++){
			GPIO_WriteBit(GPIOC,GPIO_Pin_7,(BitAction)(1));
			Delay_ms(1);
			GPIO_WriteBit(GPIOC,GPIO_Pin_7,(BitAction)(0));
			Delay_ms(1);
			}
			break;
		case Motor2:
			if(Dir == CCW){
				GPIO_WriteBit(GPIOC,GPIO_Pin_8,(BitAction)(1));
			}else if (Dir == CW){
				GPIO_WriteBit(GPIOC,GPIO_Pin_8,(BitAction)(0));
			}
			for(uint32_t i = 0; i < Pulse; i++){
			GPIO_WriteBit(GPIOC,GPIO_Pin_9,(BitAction)(1));
			Delay_ms(1);
			GPIO_WriteBit(GPIOC,GPIO_Pin_9,(BitAction)(0));
			Delay_ms(1);
			}
			break;
		case Motor3:
			if(Dir == CCW){
				GPIO_WriteBit(GPIOC,GPIO_Pin_10,(BitAction)(1));
			}else if (Dir == CW){
				GPIO_WriteBit(GPIOC,GPIO_Pin_10,(BitAction)(0));
			}
			for(uint32_t i = 0; i < Pulse; i++){
			GPIO_WriteBit(GPIOC,GPIO_Pin_11,(BitAction)(1));
			Delay_ms(1);
			GPIO_WriteBit(GPIOC,GPIO_Pin_11,(BitAction)(0));
			Delay_ms(1);
			}
			break;
		}
	return 1;
}
