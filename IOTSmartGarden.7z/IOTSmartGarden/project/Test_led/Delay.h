/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MYUART_CONFIG_H
#define __MYUART_CONFIG_H
#include "include.h"

void Delay_us(uint16_t time);
void Delay_ms(uint16_t time);

#endif /* __MYUART_CONFIG_H */

