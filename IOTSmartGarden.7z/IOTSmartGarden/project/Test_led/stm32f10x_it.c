/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "string.h"
#include "include.h"

/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

char *strstr(const char *str1, const char *str2)
{
  size_t len_str2 = strlen(str2);
  char *cur;

  for (cur = (char*)str1; cur != NULL; cur = strchr(cur, *str2)) {
    if (!strncmp(cur, str2, len_str2)) {
      break;
    }
    cur++;
  }
  return cur;
}

void USART2_IRQHandler(void)
{
	uint16_t data;
  if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
  {
		GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(1^GPIO_ReadInputDataBit(GPIOB,  GPIO_Pin_9)));
		data = USART_ReceiveData(USART2);
		if(USART_GetITStatus(USART2, USART_IT_TXE) == RESET)
			USART_SendData(USART2,data);
  }
}
char usart1_buff[30];
unsigned char count = 0;

void USART1_IRQHandler(void){
//	uint16_t data;
//UU_PutString(USART2,(uint8_t *)"OK->>>>>>>");
	/*
	uint16_t data;
  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {
		//GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(1^GPIO_ReadInputDataBit(GPIOB,  GPIO_Pin_9)));
		data = USART_ReceiveData(USART1);
		if(USART_GetITStatus(USART1, USART_IT_TXE) == RESET)
			USART_SendData(USART1,data);
  }*/
	if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) != RESET)
	{
	
		if(count<29)
		{
			 usart1_buff[count] = USART_ReceiveData(USART1);
			 if(strstr(usart1_buff,"start_water") != NULL){
				UU_PutString(USART2,(uint8_t *)"start_water");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"start_spray") != NULL){
				UU_PutString(USART2,(uint8_t *)"start_spray");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"stop_water") != NULL){
				UU_PutString(USART2,(uint8_t *)"stop_water");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"stop_spray") != NULL){
				UU_PutString(USART2,(uint8_t *)"stop_spray");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"reset_water") != NULL){
				UU_PutString(USART2,(uint8_t *)"reset_water");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"reset_spray") != NULL){
				UU_PutString(USART2,(uint8_t *)"reset_spray");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"up") != NULL){
				UU_PutString(USART2,(uint8_t *)"up");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"down") != NULL){
				UU_PutString(USART2,(uint8_t *)"down");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"backward") != NULL){
				UU_PutString(USART2,(uint8_t *)"backward");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"forward") != NULL){
				UU_PutString(USART2,(uint8_t *)"forward");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			 if(strstr(usart1_buff,"left") != NULL){
				UU_PutString(USART2,(uint8_t *)"left");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
			if(strstr(usart1_buff,"right") != NULL){
				UU_PutString(USART2,(uint8_t *)"right");
				count = 0; //Reset counter
				 for(int i = 0; i< 30 ; i++){
					 usart1_buff[i] = NULL;
				 }
			 }
		count++;
		}else count = 0; //RESET counter
}
}



/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
}
/*
struct DATA_sensor{
	uint16_t hum;
	double *lux;
	uint8_t temperature;
};
*/
uint16_t data_hum;
double lux;
int temperature;
void TIM4_IRQHandler(void){
	if(TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET){
		struct DATA_sensor data_read;
		read_data_sensor();
		//UARTPutn(USART2, 101);
		TIM_ClearFlag(TIM4, TIM_FLAG_Update); // Clear update flag 
		//decoder(data_read.hum/100, data_read.hum/100, data_read.temperature);
}
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
