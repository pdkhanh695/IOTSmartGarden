/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEFINE_CONFIG_H
#define __DEFINE_CONFIG_H
#include "include.h"
 
//Define Pinout Motor

//Define Pinout 
struct DATA_sensor{
	uint16_t hum;
	double lux;
	uint8_t temperature;
};

#endif /* __DEFINE_CONFIG_H */

